#
# Session management
#
# A time saving feature of an Editor is to be able
# to save configurations of opened file and to
# re-load this configuration later.
#
# As usual, press F5 to insert code in the macro panel
# This should remove demo 1 to 6 and
# should stop and restart the Editor in the same state.
#