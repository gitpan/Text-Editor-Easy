prove -r -I lib
